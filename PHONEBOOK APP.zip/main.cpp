//AUTHOR :SAKYI STEPHENSON
//CLASS:IT.A CLASS
//INDEX NUM: UEB3222122

#include <iostream>
#include <string>
#include <map>

class PhoneBook {
private:
    std::map<std::string, std::string> contacts;

public:
    void addContact(const std::string &name, const std::string &phoneNumber) {
        contacts[name] = phoneNumber;
    }

    void displayContact(const std::string &name) {
        std::map<std::string, std::string>::iterator it = contacts.find(name);
        if (it != contacts.end()) {
            std::cout << "Name: " << it->first << "\tPhone Number: " << it->second << std::endl;
        } else {
            std::cout << "Contact not found." << std::endl;
        }
    }

    void displayAllContacts() {
        std::cout << "----- Phone Book -----" << std::endl;
        for (std::map<std::string, std::string>::const_iterator it = contacts.begin(); it != contacts.end(); ++it) {
            std::cout << "Name: " << it->first << "\tPhone Number: " << it->second << std::endl;
        }
        std::cout << "----------------------" << std::endl;
    }
};

int main() {
    PhoneBook phoneBook;
    int choice;
    std::string name, phoneNumber;

    do {
        std::cout << "Phone Book Application" << std::endl;
        std::cout << "1. Add Contact" << std::endl;
        std::cout << "2. Display Contact" << std::endl;
        std::cout << "3. Display All Contacts" << std::endl;
        std::cout << "4. Quit" << std::endl;
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                std::cout << "Enter name: ";
                std::cin >> name;
                std::cout << "Enter phone number: ";
                std::cin >> phoneNumber;
                phoneBook.addContact(name, phoneNumber);
                break;
            case 2:
                std::cout << "Enter name to display: ";
                std::cin >> name;
                phoneBook.displayContact(name);
                break;
            case 3:
                phoneBook.displayAllContacts();
                break;
            case 4:
                std::cout << "Exiting Phone Book." << std::endl;
                break;
            default:
                std::cout << "Invalid choice. Please try again." << std::endl;
        }

    } while (choice != 4);

    return 0;
}

